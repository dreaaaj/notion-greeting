// display good morning, afternoon or evening based on the time
function displayGreeting() {
  var date = new Date();
  var hour = date.getHours();
  var description = "";
  if (hour < 12) {
    description = "morning";
  } else if (hour < 17) {
    description = "afternoon";
  } else {
    description = "evening";
  }
  document.getElementById('greeting').innerHTML = "Good " + description;
}